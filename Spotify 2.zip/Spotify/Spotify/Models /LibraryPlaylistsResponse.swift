//
//  LibraryPlaylistsResponse.swift
//  Spotify
//
//  Created by Дильназ Байбейсенова on 22.12.2021.
//

import Foundation


struct LibraryPlaylistsResponse: Codable {
    let items: [Playlist]
}
