//
//  AlbumCollectionViewCellViewModel.swift
//  Spotify
//
//  Created by Дильназ Байбейсенова on 22.12.2021.
//

import Foundation
struct AlbumCollectionViewCellViewModel {
    let name: String
    let artistName: String
}
