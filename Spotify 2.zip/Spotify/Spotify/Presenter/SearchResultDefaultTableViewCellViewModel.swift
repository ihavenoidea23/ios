//
//  SearchResultDefaultTableViewCellViewModel.swift
//  Spotify
//
//  Created by Дильназ Байбейсенова on 22.12.2021.
//

import Foundation
struct SearchResultDefaultTableViewCellViewModel {
    let title: String
    let imageURL: URL?
}
