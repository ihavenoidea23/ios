//
//  SearchResultSubtitleTableViewCellViewModel.swift
//  Spotify
//
//  Created by Дильназ Байбейсенова on 22.12.2021.
//

import Foundation
struct SearchResultSubtitleTableViewCellViewModel {
    let title: String
    let subtitle: String
    let imageURL: URL?
}
